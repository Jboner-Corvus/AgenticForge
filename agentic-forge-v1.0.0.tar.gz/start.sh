#!/bin/bash
set -e

echo "🚀 Démarrage d'AgenticForge..."

# Vérification du fichier .env
if [ ! -f ".env" ]; then
    echo "❌ Fichier .env manquant. Exécutez d'abord ./install.sh"
    exit 1
fi

# Vérification des variables critiques
source .env
if [ "$LLM_API_KEY" = "votre_cle_api_gemini" ]; then
    echo "❌ Veuillez configurer votre LLM_API_KEY dans le fichier .env"
    exit 1
fi

if [ "$AUTH_TOKEN" = "un_token_secret_et_long_genere_pour_la_prod" ]; then
    echo "❌ Veuillez configurer votre AUTH_TOKEN dans le fichier .env"
    exit 1
fi

# Test de connexion Redis
echo "📡 Test de connexion Redis..."
if ! timeout 5 bash -c "</dev/tcp/${REDIS_HOST:-localhost}/${REDIS_PORT:-6379}" 2>/dev/null; then
    echo "❌ Impossible de se connecter à Redis sur ${REDIS_HOST:-localhost}:${REDIS_PORT:-6379}"
    echo "Assurez-vous que Redis est démarré"
    exit 1
fi

echo "✅ Redis connecté"

# Démarrage des services
echo "🔄 Démarrage des services..."
echo "🌐 Interface Web: http://localhost:${WEB_PORT:-3002}"
echo "🤖 API Worker: http://localhost:${PUBLIC_PORT:-8080}"
echo ""
echo "Appuyez sur Ctrl+C pour arrêter"

# Démarrage en parallèle
pnpm start:worker &
WORKER_PID=$!

pnpm start &
WEB_PID=$!

# Gestionnaire d'arrêt propre
cleanup() {
    echo ""
    echo "🛑 Arrêt des services..."
    kill $WORKER_PID $WEB_PID 2>/dev/null || true
    wait
    echo "✅ Services arrêtés"
    exit 0
}

trap cleanup SIGINT SIGTERM

# Attente
wait
