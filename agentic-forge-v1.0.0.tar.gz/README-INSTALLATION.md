# 🚀 Installation d'AgenticForge

## Prérequis

- **Node.js 18+** : [Télécharger Node.js](https://nodejs.org/)
- **Redis** : [Guide d'installation Redis](https://redis.io/download)
- **Système** : Linux, macOS ou Windows (avec WSL recommandé)

## Installation rapide

### 1. Extraire l'archive
```bash
tar -xzf agentic-forge-v*.tar.gz
cd agentic-forge-v*/
```

### 2. Exécuter l'installation automatique
```bash
chmod +x install.sh
./install.sh
```

### 3. Configurer l'environnement
Éditez le fichier `.env` :
```bash
nano .env
```

**Variables importantes à modifier :**
- `AUTH_TOKEN` : Un token secret long pour sécuriser l'API (OBLIGATOIRE)
- `LLM_API_KEY` : Votre clé API (Gemini, OpenAI, etc.) - OPTIONNEL si vous configurez les clés via l'interface web
- `REDIS_HOST` et `REDIS_PORT` : Configuration Redis si différente

**🔑 Gestion des clés LLM :**
- **Recommandé** : Utilisez l'interface web (Settings → LLM API Keys) pour une gestion avancée
- **Basique** : Configurez `LLM_API_KEY` dans .env pour une utilisation simple

### 4. Démarrer Redis
```bash
# Ubuntu/Debian
sudo systemctl start redis

# macOS avec Homebrew
brew services start redis

# Ou directement
redis-server
```

### 5. Démarrer AgenticForge
```bash
chmod +x start.sh
./start.sh
```

## Accès à l'application

- **Interface Web** : http://localhost:3002
- **API Worker** : http://localhost:8080

## Dépannage

### Node.js manquant
```bash
# Ubuntu/Debian
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# macOS
brew install node

# Windows
# Télécharger depuis https://nodejs.org/
```

### Redis manquant
```bash
# Ubuntu/Debian
sudo apt install redis-server
sudo systemctl start redis

# macOS
brew install redis
brew services start redis
```

### Erreur de permissions
```bash
chmod +x install.sh start.sh
```

### Port déjà utilisé
Modifiez `PUBLIC_PORT` et `WEB_PORT` dans le fichier `.env`

## Support

Pour obtenir de l'aide :
1. Vérifiez les logs dans la console
2. Consultez la documentation complète
3. Contactez le support technique
