#!/bin/bash
set -e

echo "🚀 Installation d'AgenticForge..."

# Vérification des prérequis
echo "📋 Vérification des prérequis..."
if ! command -v node >/dev/null 2>&1; then
    echo "❌ Node.js n'est pas installé. Veuillez installer Node.js 18+ avant de continuer."
    exit 1
fi

if ! command -v pnpm >/dev/null 2>&1; then
    echo "⚠️  pnpm n'est pas installé. Installation automatique..."
    npm install -g pnpm
fi

NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js version 18+ requis. Version actuelle: $(node --version)"
    exit 1
fi

echo "✅ Node.js $(node --version) détecté"
echo "✅ pnpm $(pnpm --version) détecté"

# Configuration de l'environnement
echo "⚙️  Configuration de l'environnement..."
if [ ! -f ".env" ]; then
    cp .env.template .env
    echo "📝 Fichier .env créé depuis le template"
    echo "⚠️  IMPORTANT: Éditez le fichier .env avec vos vraies valeurs avant de démarrer"
else
    echo "ℹ️  Le fichier .env existe déjà"
fi

# Installation des dépendances
echo "📦 Installation des dépendances..."
pnpm install --frozen-lockfile --prod

echo ""
echo "🎉 Installation terminée !"
echo ""
echo "📋 Prochaines étapes :"
echo "1. Éditez le fichier .env avec vos vraies valeurs"
echo "2. Assurez-vous que Redis est démarré"
echo "3. Démarrez l'application avec: ./start.sh"
echo ""
